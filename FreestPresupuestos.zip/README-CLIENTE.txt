═══════════════════════════════════════════════════════════════
          🧳 Freest Travel - Sistema de Presupuestos
═══════════════════════════════════════════════════════════════

CÓMO USAR:

1. Descomprime este archivo ZIP en cualquier carpeta
   (ej: Escritorio, Documentos, etc.)

2. Haz doble-click en "INICIAR.command"

3. Si es la primera vez:
   - Si te pide instalar Node.js, sigue las instrucciones
   - Espera mientras se instalan las dependencias (solo la primera vez)

4. El navegador se abrirá automáticamente con el sistema

5. Para cerrar: cierra la ventana de Terminal que se abrió


SOLUCIÓN DE PROBLEMAS:

❓ "INICIAR.command" no se ejecuta
   → Click derecho > Abrir > Abrir de todos modos

❓ Aparece error de permisos
   → Abre Terminal y ejecuta:
     chmod +x INICIAR.command

❓ El navegador no abre automáticamente
   → Visita manualmente: http://localhost:3000


SOPORTE:
Contactar a Freest Travel para asistencia técnica
═══════════════════════════════════════════════════════════════
